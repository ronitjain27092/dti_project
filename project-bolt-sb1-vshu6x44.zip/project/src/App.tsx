import React, { useState } from 'react';
import { Package, Truck, Clock, MapPin, Search, User, Bell, Box, ArrowRight } from 'lucide-react';

function App() {
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="relative">
                <div className="absolute -inset-1 bg-blue-500 rounded-lg blur opacity-25 group-hover:opacity-100 transition duration-200"></div>
                <Truck className="relative h-8 w-8 text-blue-600 transform -rotate-6" />
              </div>
              <span className="ml-2 text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 text-transparent bg-clip-text">SwiftRoute</span>
            </div>
            <div className="flex items-center space-x-4">
              <button className="p-2 rounded-full hover:bg-blue-50 transition duration-200">
                <Bell className="h-5 w-5 text-gray-600" />
              </button>
              <button className="p-2 rounded-full bg-blue-100 hover:bg-blue-200 transition duration-200">
                <User className="h-5 w-5 text-blue-600" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Track Your Delivery</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">Real-time updates and precise tracking for your packages, ensuring peace of mind with every delivery.</p>
        </div>

        {/* Search Section */}
        <div className="relative mb-12 max-w-2xl mx-auto transform transition-all duration-300" 
             style={{ transform: isSearchFocused ? 'scale(1.02)' : 'scale(1)' }}>
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className={`h-5 w-5 ${isSearchFocused ? 'text-blue-500' : 'text-gray-400'} transition-colors duration-200`} />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-4 border-2 border-gray-200 rounded-xl leading-5 bg-white placeholder-gray-500 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 sm:text-sm"
            placeholder="Enter your tracking number..."
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setIsSearchFocused(false)}
          />
          <button className="absolute right-2 top-1/2 transform -translate-y-1/2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200">
            Track
          </button>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="group bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 cursor-pointer">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-blue-100 p-3 rounded-lg group-hover:bg-blue-200 transition-colors duration-200">
                <Package className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium text-gray-900">Active Deliveries</h3>
                <div className="flex items-baseline">
                  <p className="text-3xl font-bold text-blue-600">12</p>
                  <span className="ml-2 text-sm text-gray-500">packages</span>
                </div>
              </div>
            </div>
          </div>

          <div className="group bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 cursor-pointer">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-green-100 p-3 rounded-lg group-hover:bg-green-200 transition-colors duration-200">
                <Clock className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium text-gray-900">On Time</h3>
                <div className="flex items-baseline">
                  <p className="text-3xl font-bold text-green-600">98</p>
                  <span className="ml-2 text-sm text-gray-500">% success</span>
                </div>
              </div>
            </div>
          </div>

          <div className="group bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 cursor-pointer">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-purple-100 p-3 rounded-lg group-hover:bg-purple-200 transition-colors duration-200">
                <MapPin className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium text-gray-900">Total Destinations</h3>
                <div className="flex items-baseline">
                  <p className="text-3xl font-bold text-purple-600">45</p>
                  <span className="ml-2 text-sm text-gray-500">cities</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Deliveries */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
            <h2 className="text-lg font-medium text-gray-900">Recent Deliveries</h2>
            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center">
              View All <ArrowRight className="h-4 w-4 ml-1" />
            </button>
          </div>
          <div className="divide-y divide-gray-100">
            {[1, 2, 3].map((item) => (
              <div key={item} className="px-6 py-4 hover:bg-gray-50 transition-colors duration-150">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <Box className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-900">Order #{item}234</p>
                      <p className="text-sm text-gray-500">123 Main St, City</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-blue-600">In Transit</p>
                    <p className="text-sm text-gray-500">Est. 30 mins</p>
                  </div>
                </div>
                <div className="mt-3">
                  <div className="relative pt-1">
                    <div className="overflow-hidden h-2 text-xs flex rounded-full bg-blue-100">
                      <div 
                        className="w-2/3 shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-gradient-to-r from-blue-500 to-blue-600"
                        style={{ transition: 'width 1s ease-in-out' }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;